//WAP to find the sum of given two number.

#include<stdio.h>
#include<conio.h>
void main()
{
    int a,b,sum;
    printf("Enter two number:");
    scanf("%d%d",&a,&b);
    sum=a+b;
    printf("Sum of two number is %d",sum);
    getch();
}