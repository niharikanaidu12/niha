/*********************************************************************************
 Statement - Check whether a given integer is odd or even
 Programmer - Vineet Choudhary
 Written For - https://turboc.codeplex.com
 *********************************************************************************/

#include <stdio.h>
#include <conio.h>

void main()
{
   int ival, remainder;

   clrscr();

   printf("Enter an integer :");
   scanf ("%d", &ival);

   remainder = ival % 2;

   if (remainder == 0)
	printf ("%d, is an even integer\n", ival);
   else
	printf ("%d, is an odd integer\n", ival);
    
    getch();

}
/*-----------------------------
Output

RUN1

Enter an integer :13
13, is an odd integer

RUN2
Enter an integer :24
24, is an even integer

---------------------------------*/

